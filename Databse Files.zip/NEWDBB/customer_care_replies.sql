-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: customer_care
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `replies`
--

DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int NOT NULL,
  `reply` text NOT NULL,
  `reply_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replies`
--

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
INSERT INTO `replies` VALUES (1,1,'r4frffff','2024-09-19 05:10:04'),(2,1,'frfff','2024-09-19 05:10:07'),(3,1,'dfffff','2024-09-19 05:10:20'),(4,1,'ddd','2024-09-19 23:51:31'),(5,1,'ff','2024-09-20 08:57:13'),(6,1,'ff','2024-09-20 09:10:43'),(11,6,'fff','2024-09-21 01:34:12'),(15,15,'fgfyyyyyy','2024-09-21 03:04:08'),(162,41,'vvfv','2024-09-21 11:13:06'),(163,41,'vfgg','2024-09-21 11:13:08'),(164,41,'vvvv','2024-09-21 11:13:11'),(165,41,'dd','2024-09-21 11:14:04'),(166,42,'dfdfdffffffffffffff','2024-09-21 11:14:31'),(167,42,'gggffddddd','2024-09-21 11:27:21'),(168,43,'ffrrrccdd','2024-09-21 11:23:11'),(169,43,'ffff','2024-09-21 11:21:41'),(170,42,'ccc','2024-09-21 11:23:51'),(171,42,'ccc','2024-09-21 11:24:10'),(172,42,'helloddrrrr','2024-09-21 11:30:20'),(173,45,'rrtttrr6fffdfdddd','2024-09-21 11:37:55'),(174,45,'hello','2024-09-21 11:37:49'),(175,45,'dffee ff rgr g rg gjnrgff fff jfnfnfffggg','2024-09-21 11:38:08'),(176,45,'ddd','2024-09-21 11:41:25'),(177,46,'ff','2024-09-21 11:41:34'),(178,46,'dd','2024-09-21 11:42:15'),(179,46,'ddd','2024-09-21 11:44:40'),(180,46,'dd','2024-09-21 11:44:47'),(181,46,'dd','2024-09-21 11:44:53'),(182,47,'rfffdd','2024-09-21 11:48:34'),(183,47,'rr','2024-09-21 11:45:02'),(184,47,'dd','2024-09-21 11:48:23'),(185,51,'fdvf','2024-09-23 07:38:25'),(186,51,'fgfgvfvjhf','2024-09-23 07:38:33'),(187,52,'hello g','2024-09-23 17:08:27'),(188,52,'ff','2024-09-23 17:08:31'),(189,52,'hturf','2024-09-23 17:08:34'),(190,54,'zfgdg fdg dsfd','2024-10-10 14:01:28'),(191,54,'vjbhk,h','2024-10-10 14:01:57'),(192,54,'fvhy','2024-10-10 14:02:01'),(193,49,'gdh','2024-10-11 07:21:00'),(194,49,'bb','2024-10-11 07:21:03'),(195,49,'gggyyy','2024-10-13 16:01:22'),(196,66,'hello','2024-10-14 03:28:22');
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-14 10:02:52
