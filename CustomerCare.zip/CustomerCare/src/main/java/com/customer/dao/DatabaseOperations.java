package com.customer.dao;

import java.util.List;


import com.customer.model.Admin;

public interface DatabaseOperations {

    boolean validate(String username, String password);

    List<Admin> getAdmin(String userName);

    boolean insertArticle(String title, String content, String date);

    List<com.customer.model.KnowledgebaseArticle> getAllArticles();

    boolean deleteArticle(int id);

    boolean updateArticle(int id, String title, String content, String date);
}