package com.customer.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.customer.model.Agent;
import com.customer.utill.DBConnect;


public class AgentDBUtil {

    private static boolean isSuccess;
    private static Connection con = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;

    
    public static boolean validate(String name, String password) {
        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();

            String sql = "SELECT * FROM agent WHERE name='" + name + "' AND password='" + password + "'";
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
                isSuccess = true;
            } else {
                isSuccess = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }
    
    public static  List < Agent> getAgent(String name) {

    	ArrayList<Agent> agent = new ArrayList<>();

        try {
            con = DBConnect.getConnection();
            stmt = con.createStatement();
            String sql = "SELECT * FROM agent WHERE name=" + name;
            rs = stmt.executeQuery(sql);

            if (rs.next()) {
            	int agentid = rs.getInt("agentid");
                String userName = rs.getString("name");
                String email = rs.getString("email");
                int phone = rs.getInt("phone");
                String password = rs.getString("password");

                Agent agnt= new Agent(agentid, name, email, phone, password);
                agent.add(agnt);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return agent;
    }
    
    
}



