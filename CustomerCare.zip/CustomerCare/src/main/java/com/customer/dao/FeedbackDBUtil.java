package com.customer.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.dbcp.dbcp2.PStmtKey;

import com.customer.model.Feedback;



public class FeedbackDBUtil {

	public static List<Feedback> display(String name, String email, String message)
	{
		ArrayList<Feedback> feed = new ArrayList<>();
		
		//create database connection
		String url = "jdbc:mysql://localhost:3306/customer_care";
		String user = "root";
		String password = "Sandaru2002@";
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url, user, password);
			Statement stmt = con.createStatement();
			
			String sql = "select * from feedback where name='"+name+"' and email= '"+email+"' and message= '"+message+"'";
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next())
			{
				String name1 = rs.getString(2);
				String email1 = rs.getString(3);
				String message1 = rs.getString(4);
			}
			
			Feedback f = new Feedback(name, email, message);
			
			feed.add(f);			
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return feed;
	}
}
