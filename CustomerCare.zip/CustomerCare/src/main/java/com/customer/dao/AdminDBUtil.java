package com.customer.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.customer.model.Admin;
import com.customer.model.KnowledgebaseArticle;
import com.customer.model.agentmanagement;
import com.customer.utill.DBConnect;

public class AdminDBUtil implements DatabaseOperations {
	
	
	private static AdminDBUtil instance;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
	// private constructor to restrict instantiation
    private AdminDBUtil() {
        
        con = DBConnect.getConnection();
    }
    
 // public method to provide access to the single instance
    public static AdminDBUtil getInstance() {
        if (instance == null) {
            synchronized (AdminDBUtil.class) {
                if (instance == null) {
                    instance = new AdminDBUtil();
                }
            }
        }
        return instance;
    }
	
	@Override
	public boolean validate(String username,String password) {
		boolean isSuccess = false;
		try {
			stmt = con.createStatement();
			String sql ="select * from admin where username='"+username+"' and password='"+password+"'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				isSuccess = true;
			}else {
				isSuccess = false;
			}
			
		} catch(Exception e){
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	@Override
	public  List <Admin> getAdmin(String userName){
		
		ArrayList<Admin> admin = new ArrayList<>();
		
		try {
			stmt = con.createStatement();
			String sql ="select * from admin where username='"+userName+"'";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String userU = rs.getString(4);
				String passU = rs.getString(5);
				
				Admin adm = new Admin(id,name,email,userU,passU);
				admin.add(adm);
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return admin;
		
	}
	
	
	//Add Article to KnowlwdgeBase
	
	public boolean insertArticle(String title,String content,String date) {
		boolean isSuccess = false;
		
		try {
			stmt = con.createStatement();
			
			
			String sql = "insert into knowledgebase (title, content, date) values ('"+title+"', '"+content+"', '"+date+"')";
			int rs = stmt.executeUpdate(sql);
			
			if (rs > 0) {
				isSuccess = true;
			}else {
				isSuccess = false;
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	//View Article  Data  KnowlwdgeBase
	
	public List<KnowledgebaseArticle> getAllArticles() {
	    List<KnowledgebaseArticle> articles = new ArrayList<>();

	    try {
	        con = DBConnect.getConnection();
	        stmt = con.createStatement();
	        String sql = "SELECT * FROM knowledgebase"; 
	        rs = stmt.executeQuery(sql);

	        while (rs.next()) {
	            int id = rs.getInt("id");
	            String title = rs.getString("title");
	            String content = rs.getString("content");
	            String date = rs.getString("date");

	            KnowledgebaseArticle article = new KnowledgebaseArticle(id, title, content, date);
	            articles.add(article);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return articles;
	}
	
	// Delete Article
	
	@Override
	public  boolean deleteArticle(int id) {
	    boolean isSuccess = false;

	    try {
	        stmt = con.createStatement();
	        String sql = "DELETE FROM knowledgebase WHERE id=" + id;
	        int rs = stmt.executeUpdate(sql);

	        if (rs > 0) {
	            isSuccess = true;
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return isSuccess;
	}
	
	//Update Article
	
	public static KnowledgebaseArticle getArticleById(int id) {
	    KnowledgebaseArticle article = null;

	    try {
	        
	        con = DBConnect.getConnection();
	        stmt = con.createStatement();
	        
	        
	        String sql = "SELECT * FROM knowledgebase WHERE id=" + id;
	        rs = stmt.executeQuery(sql);

	        // If a result is found, create a KnowledgebaseArticle object
	        if (rs.next()) {
	            String title = rs.getString("title");
	            String content = rs.getString("content");
	            String date = rs.getString("date");

	            // Initialize the article object
	            article = new KnowledgebaseArticle(id, title, content, date);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    
	    return article;
	}
	
	
	public boolean updateArticle(int id, String title, String content, String date) {
	    boolean isSuccess = false;

	    try {
	        con = DBConnect.getConnection();
	        stmt = con.createStatement();

	        String sql = "UPDATE knowledgebase SET title='" + title + "', content='" + content + "', date='" + date + "' WHERE id=" + id;
	        int rs = stmt.executeUpdate(sql);

	        if (rs > 0) {
	            isSuccess = true;
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return isSuccess;
	}
	
	//Add  to agent manager
	
			public static boolean insertAgent(String name, String email, int phone,String password) {
				boolean isSuccess = false;
				
				try {
					con = DBConnect.getConnection();
					stmt = con.createStatement();
					
					
					String sql = "insert into agent (name, email, phone,password) values ('"+name+"', '"+email+"', '"+phone+"','"+password+"')";
					int rs = stmt.executeUpdate(sql);
					
					if (rs > 0) {
						isSuccess = true;
					}else {
						isSuccess = false;
					}
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				return isSuccess;
			}
		
		//View agent manager
		
		public static List<agentmanagement> getAllAgent() {
		    List<agentmanagement> agents = new ArrayList<>();

		    try {
		        con = DBConnect.getConnection();
		        stmt = con.createStatement();
		        String sql = "SELECT * FROM agent"; 
		        rs = stmt.executeQuery(sql);

		        while (rs.next()) {
		            int agentid = rs.getInt("agentid");
		            String name = rs.getString("name");
		            String email = rs.getString("email");
		            int phone = rs.getInt("phone");
		            String password = rs.getString("password");

		            agentmanagement agent = new agentmanagement(agentid, name, email, phone,password);
		            agents.add(agent);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    return agents;
		}
		
		// Delete Agent
		
		public static boolean deleteAgent(int agentid) {
		    boolean isSuccess = false;

		    try {
		        con = DBConnect.getConnection();
		        stmt = con.createStatement();
		        String sql = "DELETE FROM agent WHERE agentid=" + agentid;
		        int rs = stmt.executeUpdate(sql);

		        if (rs > 0) {
		            isSuccess = true;
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    return isSuccess;
		}
		
		//Update Agent
		
		
		public static agentmanagement getAgentById(int agentid) {
			agentmanagement agent = null;

		    try {
		        
		        con = DBConnect.getConnection();
		        stmt = con.createStatement();
		        
		        
		        String sql = "SELECT * FROM agent WHERE agentid=" + agentid;
		        rs = stmt.executeQuery(sql);

		        
		        if (rs.next()) {
		        	
		            String name = rs.getString("name");
		            String email = rs.getString("email");
		            int phone = rs.getInt("phone");
		            String password = rs.getString("password");

		            
		            agent = new agentmanagement(agentid, name, email, phone,password);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    
		    return agent;
		}
		
		public static boolean updateAgent(int agentid, String name, String email, int phone,String password) {
		    boolean isSuccess = false;

		    try {
		        con = DBConnect.getConnection();
		        stmt = con.createStatement();

		        String sql = "UPDATE agent SET name='" + name + "', email='" + email + "', phone='" + phone + "',password='"+password+"' WHERE agentid=" + agentid;
		        int rs = stmt.executeUpdate(sql);

		        if (rs > 0) {
		            isSuccess = true;
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    return isSuccess;
		}
		
		
		// Search Knowledgebase Articles by keyword
		public static List<KnowledgebaseArticle> searchArticles(String keyword) {
		    List<KnowledgebaseArticle> articles = new ArrayList<>();

		    try {
		        
		        con = DBConnect.getConnection();
		        stmt = con.createStatement();

		        // SQL query to search articles by title or content using the keyword
		        String sql = "SELECT * FROM knowledgebase WHERE title LIKE '%" + keyword + "%' OR content LIKE '%" + keyword + "%'";
		        rs = stmt.executeQuery(sql);

		        
		        while (rs.next()) {
		            int id = rs.getInt("id");
		            String title = rs.getString("title");
		            String content = rs.getString("content");
		            String date = rs.getString("date");

		            KnowledgebaseArticle article = new KnowledgebaseArticle(id, title, content, date);
		            articles.add(article);
		        }
		    } catch (Exception e) {
		        e.printStackTrace();
		    }

		    return articles;
		}
	
}






