package com.customer.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.customer.dao.AgentDBUtil;
import com.customer.model.Agent;

@WebServlet("/agentLogin")
public class AgentLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String name = request.getParameter("name");
        String password = request.getParameter("password");
        boolean isValid;
        
        

        try {
            isValid = AgentDBUtil.validate(name, password);

            if (isValid) {
                List<Agent> agentDetails = AgentDBUtil.getAgent(name);
                request.setAttribute("agentDetails", agentDetails);

                HttpSession session1 = request.getSession();
                session1.setAttribute("name", name);

                RequestDispatcher dis = request.getRequestDispatcher("agentDashboard.jsp");
                dis.forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Your username or password is incorrect.");
                RequestDispatcher dis = request.getRequestDispatcher("agentLogin.jsp");
                dis.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the error
            request.setAttribute("errorMessage", "An error occurred during login. Please try again.");
            RequestDispatcher dis = request.getRequestDispatcher("agentLogin.jsp");
            dis.forward(request, response);
        }
    }
}
