package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.customer.dao.AdminDBUtil;



@WebServlet("/UpdateKnowledgeServlet")
public class UpdateKnowledgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String date = request.getParameter("date");
        
     // Call the method to update the article in the database
        boolean isUpdated = AdminDBUtil.getInstance().updateArticle(id, title, content, date);

        if (isUpdated) {
            // If successful, redirect to the knowledge base page
            response.sendRedirect("updateartisucessfull.jsp");
            
    
        } else {
            // If not successful, you can redirect to an error page or display an error message
            response.sendRedirect("udatearticleerror.jsp");
        }
    
        
        
	}

}
