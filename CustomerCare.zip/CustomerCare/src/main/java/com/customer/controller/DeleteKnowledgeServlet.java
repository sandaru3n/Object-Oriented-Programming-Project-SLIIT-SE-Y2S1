package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.customer.dao.AdminDBUtil;


@WebServlet("/delete_knowledge")
public class DeleteKnowledgeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String articleId = request.getParameter("id");
        
     // c all the method to delete the article
        boolean isDeleted = AdminDBUtil.getInstance().deleteArticle(Integer.parseInt(articleId));
       
   
        if (isDeleted) {
            
            response.sendRedirect("manageKnowledgebase.jsp");
        } else {
            
            response.sendRedirect("manageKnowledgebase.jsp");
        }
    }
	
	
}
