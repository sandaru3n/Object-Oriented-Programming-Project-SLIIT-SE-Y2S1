package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/EditReplyServlet")
public class EditReplyServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int replyId = Integer.parseInt(request.getParameter("reply_id"));
        String newReplyText = request.getParameter("reply");
        int ticketId = 0; // Initialize ticketId

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_care", "root", "Sandaru2002@");

            // Fetch the ticketId associated with the replyId
            String ticketIdSql = "SELECT ticket_id FROM replies WHERE id = ?";
            PreparedStatement ticketIdStmt = connection.prepareStatement(ticketIdSql);
            ticketIdStmt.setInt(1, replyId);
            ResultSet ticketIdRs = ticketIdStmt.executeQuery();
            if (ticketIdRs.next()) {
                ticketId = ticketIdRs.getInt("ticket_id"); // Get the ticketId
            }

            // Update the reply
            String sql = "UPDATE replies SET reply = ?, reply_date = NOW() WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, newReplyText);
            preparedStatement.setInt(2, replyId);
            preparedStatement.executeUpdate();
            connection.close();

            request.setAttribute("successMessage", "Reply updated successfully.");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error updating reply.");
        }

        // Forward to ticket details with the retrieved ticketId
        request.getRequestDispatcher("ticketdetails.jsp?id=" + ticketId).forward(request, response);
    }
}
