package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.customer.dao.AdminDBUtil;

@WebServlet("/DeleteAgentServlet")
public class DeleteAgentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        
        String agentid = request.getParameter("agentid");
        
        try {
            // Call the method to delete the agent
            boolean isDeleted = AdminDBUtil.deleteAgent(Integer.parseInt(agentid));
            
            if (isDeleted) {
                
                response.sendRedirect("agent_management.jsp");
            } else {
                
                response.sendRedirect("agent_management.jsp");
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            // Handle potential number format exception if `agentId` is not a valid integer
            response.sendRedirect("agent_management.jsp");
        }
    }
}
