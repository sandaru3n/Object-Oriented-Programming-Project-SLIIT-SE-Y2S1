package com.customer.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ReplyTicketServlet")
public class ReplyTicketServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String ticketIdParam = request.getParameter("ticket_id");
        String replyText = request.getParameter("reply");
        
        int ticketId = Integer.parseInt(ticketIdParam);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_care", "root", "Sandaru2002@");

            String sql = "INSERT INTO replies (ticket_id, reply) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, ticketId);
            preparedStatement.setString(2, replyText);

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                request.setAttribute("successMessage", "Reply sent successfully!");
            } else {
                request.setAttribute("errorMessage", "Failed to send reply.");
            }
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
        }

        // Redirect back to the ticket details page
        response.sendRedirect("ticketdetails.jsp?id=" + ticketId);
    }
}
