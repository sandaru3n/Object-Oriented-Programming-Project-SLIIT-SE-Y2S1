package com.customer.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.customer.dao.AdminDBUtil;

@WebServlet("/CreateAgent")
public class CreateAgent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CreateAgent() {
        super();
        
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//String agentidStr = request.getParameter("agentid");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phoneStr = request.getParameter("phone");
		String password = request.getParameter("password");
		
		
		int phone = 0;
		try {
            //agentid = Integer.parseInt(agentidStr);
            phone = Integer.parseInt(phoneStr);
        } catch (NumberFormatException e) {
            // Handle parsing errors or invalid input
            e.printStackTrace();
        }
boolean isTrue;
		
		isTrue = AdminDBUtil.insertAgent(name, email, phone,password);
		
		if (isTrue == true ) {
			RequestDispatcher dis = request.getRequestDispatcher("agentcreatesucess.jsp");
			dis.forward(request, response);
		}
		else {
			RequestDispatcher dis2 = request.getRequestDispatcher("agentcreateunsuccess.jsp");
			dis2.forward(request, response);	
		}
		
		
	}

}
