package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.customer.dao.AdminDBUtil;


@WebServlet("/UpdateAgentServlet")
public class UpdateAgentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        try {
            // Retrieve agent details from the form
            int agentid = Integer.parseInt(request.getParameter("agentid"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            int phone = Integer.parseInt(request.getParameter("phone"));
            String password = request.getParameter("password");
            
            // Validate the inputs (optional but recommended)
            if (name == null || name.isEmpty() || email == null || email.isEmpty()) {
                response.sendRedirect("updateagenterror.jsp");
                return;
            }
            
            // Call the method to update the agent in the database
            boolean isUpdated = AdminDBUtil.updateAgent(agentid, name, email, phone,password);

            if (isUpdated) {
                
                response.sendRedirect("updateagentsucessfull.jsp");
            } else {
                
                response.sendRedirect("updateagenterror.jsp");
            }
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
            response.sendRedirect("updateagenterror.jsp");
        } catch (Exception e) {
            
            e.printStackTrace();
            response.sendRedirect("updateagenterror.jsp");
        }
    }
}
