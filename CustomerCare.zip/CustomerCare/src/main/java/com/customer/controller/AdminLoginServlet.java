package com.customer.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.customer.dao.AdminDBUtil;
import com.customer.model.Admin;

@WebServlet("/adminLogin")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String userName = request.getParameter("username");
        String password = request.getParameter("password");
        boolean isValid;
        
        

        try {
            isValid = AdminDBUtil.getInstance().validate(userName, password);

            if (isValid) {
                List<Admin> admDetails = AdminDBUtil.getInstance().getAdmin(userName);
                request.setAttribute("admDetails", admDetails);

                HttpSession session1 = request.getSession();
                session1.setAttribute("adminUsername", userName);

                RequestDispatcher dis = request.getRequestDispatcher("adminDashboard.jsp");
                dis.forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Your username or password is incorrect.");
                RequestDispatcher dis = request.getRequestDispatcher("adminLogin.jsp");
                dis.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the error
            request.setAttribute("errorMessage", "An error occurred during login. Please try again.");
            RequestDispatcher dis = request.getRequestDispatcher("adminLogin.jsp");
            dis.forward(request, response);
        }
    }
}
