package com.customer.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CreateTicketServlet")
public class CreateTicketServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String subject = request.getParameter("subject");
        String description = request.getParameter("description");
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String username = (String) session.getAttribute("username");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_care", "root", "Sandaru2002@");

            // Updated SQL query to include the status column
            String sql = "INSERT INTO tickets (username, subject, description, status) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, subject);
            preparedStatement.setString(3, description);
            preparedStatement.setString(4, "Open"); // Setting the default status to 'Open'

            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                request.setAttribute("successMessage", "Ticket created successfully!");
            } else {
                request.setAttribute("errorMessage", "Ticket creation failed, please try again.");
            }
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred: " + e.getMessage());
        }

        // Forward to dashboard or another page
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}
