package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.customer.model.Admin;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Simulating a database service for validation and updating password
    private Admin userService = new Admin(0, null, null, null, null);

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
       
        if (session == null || session.getAttribute("adminUsername") == null) {
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        // Retrieve form parameters
        String adminUsername = (String) session.getAttribute("adminUsername");
        String oldPassword = request.getParameter("oldPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        // Simple validation
        if (newPassword == null || confirmPassword == null || !newPassword.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "New passwords do not match.");
            request.getRequestDispatcher("Adminchange_password.jsp").forward(request, response);
            return;
        }

        // Check if the old password is correct (simulate database validation)
        if (userService.validateUserPassword(adminUsername, oldPassword)) {
            
            boolean passwordUpdated = userService.updateUserPassword(adminUsername, newPassword);
            
            if (passwordUpdated) {
                request.setAttribute("successMessage", "Password updated successfully.");
                request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Failed to update password. Please try again.");
                request.getRequestDispatcher("Adminchange_password.jsp").forward(request, response);
            }
        } else {
            // Old password is incorrect
            request.setAttribute("errorMessage", "Old password is incorrect.");
            request.getRequestDispatcher("Adminchange_password.jsp").forward(request, response);
        }
    }
}
