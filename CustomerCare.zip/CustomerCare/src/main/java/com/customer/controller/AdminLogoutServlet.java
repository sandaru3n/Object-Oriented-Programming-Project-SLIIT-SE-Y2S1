package com.customer.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AdminLogout")
public class AdminLogoutServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Get the current session
		HttpSession session1 = request.getSession(false); // false means don't create if it doesn't existt

		// invalidate the session if it exists
		if (session1 != null) {
			session1.invalidate();
		}

		// redirect to login page after logout
		response.sendRedirect("adminLogin.jsp");

}
}