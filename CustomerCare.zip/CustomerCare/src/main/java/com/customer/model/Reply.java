package com.customer.model;

import java.sql.Timestamp;

public class Reply {
    private int id;
    private int ticketId;
    private String reply;
    private Timestamp replyDate;
    private boolean edited; // Add this field

    public Reply(int id, int ticketId, String reply, Timestamp replyDate) {
        this.id = id;
        this.ticketId = ticketId;
        this.reply = reply;
        this.replyDate = replyDate;
        this.edited = false; // Default value
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getTicketId() { return ticketId; }
    public void setTicketId(int ticketId) { this.ticketId = ticketId; }
    public String getReply() { return reply; }
    public void setReply(String reply) { 
        this.reply = reply; 
        this.edited = true; // Set to true when reply is edited
    }
    public Timestamp getReplyDate() { return replyDate; }
    public void setReplyDate(Timestamp replyDate) { this.replyDate = replyDate; }
    public boolean isEdited() { return edited; } // Add this method
}
