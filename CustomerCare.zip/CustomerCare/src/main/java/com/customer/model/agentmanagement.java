package com.customer.model;

public class agentmanagement {
	private int agentid;
    private String name;
    private String email;
    private int phone;
    private String password;
    
    public agentmanagement(int agentid, String name, String email, int phone,String password) {
        this.agentid = agentid;
        this.name = name;
        this.email = email;
        this.phone = phone;
          
    }

	public int getAgentid() {
		return agentid;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}
	
	public int getPhone() {
		return phone;
	}
	public String getPassword() {
        return password;
    }
}


