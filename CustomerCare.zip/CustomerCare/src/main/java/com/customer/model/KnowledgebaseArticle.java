package com.customer.model;

public class KnowledgebaseArticle {
	private int id;
    private String title;
    private String content;
    private String date;
    
    public KnowledgebaseArticle(int id, String title, String content, String date) {
    this.id = id;
    this.title = title;
    this.content = content;
    this.date = date;
      
}

	public int getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getContent() {
		return content;
	}

	public String getDate() {
		return date;
	}
}


