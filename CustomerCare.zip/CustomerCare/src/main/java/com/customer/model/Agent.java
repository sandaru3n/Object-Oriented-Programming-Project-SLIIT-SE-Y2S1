package com.customer.model;

public class Agent {
	private int id;
    private String name;
    private String email;
    private int phone;
    private String password;
    
    public Agent(int id, String name, String email, int phone, String password) {
	this.id = id;
	this.name = name;
	this.email = email;
	this.phone = phone;
	this.password = password;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getPhone() {
        return phone;
    }

    public String getPassword() {
        return password;
    }    

}
